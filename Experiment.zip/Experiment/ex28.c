//  Write a program to evaluate the series sum=1-x+x^2/2!-x^3/3!+x^4/4!......-x^9/9! 

#include<stdio.h>

int main(int argc, char const *argv[])
{
    int n;
    double sum=0.0;
    scanf("%d",&n);

    for (double i = 1; i <= n; i++)
    {
        for (double j = 1; j < count; j++)
        {
            
        }
        
    }
    
    return 0;
}
