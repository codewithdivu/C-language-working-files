#include <stdio.h>
#include<stdlib.h>

int main(int argc, char const *argv[])
{
    // printf("Hello world");
    // int a = 10;
    // float b = 1.3;
    // char c = 'D';

    // printf("integer is %d\n",a);
    // printf("float is %f\n",b);
    // printf("char is %c\n",c);

    // ternary operators
    // int time = 4;
    // (time>20)?printf("greater than 20"):printf("less than 20");

    // STRINGS
    // char str[] = "Hello everyone";
    // printf("%s",str);

    // int num;
    // scanf("%d",&num);
    // printf("num is %d",num);

    // char name[10];

    // scanf("%s",name);

    // printf("name is %s",name);


    // int age = 18;
    // printf("%p",&age);

    // const int a = 10;
    // const float b = 10.5;
    // const char c = 'a';

    
    return 0;
}