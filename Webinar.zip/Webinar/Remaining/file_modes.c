


// r - open a file in read mode
// w - opens or create a text file in write mode
// a - opens a file in append mode
// r+ - opens a file in both read and write mode
// a+ - opens a file in both read and write mode
// w+ - opens a file in both read and write mode