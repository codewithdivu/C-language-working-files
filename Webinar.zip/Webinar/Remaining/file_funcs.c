


// used to open an existing file or a new file	fopen()

// writing data into an available file	fprintf()

// reading the data available in a file	fscanf()

// writing any character into the program file	fputc()

// reading the character from an available file	fgetc()

// used to close the program file	fclose()

// used to set the file pointer to the intended file position	fseek()

// writing an integer into an available file	fputw()

// used to read an integer from the given file	fgetw()

// used for reading the current position of a file	ftell()

// sets an intended file pointer to the file’s beginning itself	rewind()